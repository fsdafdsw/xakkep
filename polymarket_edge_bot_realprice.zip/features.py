
import random

def compute_quality(m):
    return random.uniform(0.6,1.0)

def compute_momentum(m):
    return random.uniform(-0.2,0.4)

def compute_anomaly(m):
    return random.uniform(0,0.3)

def compute_orderbook_signal(m):
    return random.uniform(0,0.3)
