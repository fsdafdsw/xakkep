
from scanner import fetch_markets
from strategy import evaluate_market
from probability_model import estimated_probability
from telegram import send_message
from config import *

import datetime

def run():

    markets=fetch_markets(SCAN_LIMIT)

    accepted=[]
    rejects={"low_liquidity":0,"low_volume":0,"no_price":0}

    for m in markets:

        if m["liquidity"]<MIN_LIQUIDITY:
            rejects["low_liquidity"]+=1
            continue

        if m["volume"]<MIN_VOLUME:
            rejects["low_volume"]+=1
            continue

        if m["price"] is None:
            rejects["no_price"]+=1
            continue

        metrics=evaluate_market(m)
        accepted.append((m,metrics))

    value_bets=[]
    watchlist=[]

    for m,metrics in accepted:

        price=m["price"]
        prob=estimated_probability(metrics)
        edge=prob-price

        link=f"https://polymarket.com/event/{m['slug']}"

        if edge>EDGE_THRESHOLD:

            value_bets.append({
                "question":m["question"],
                "link":link,
                "price":price,
                "prob":prob,
                "edge":edge
            })

        elif edge>WATCH_THRESHOLD:

            watchlist.append({
                "question":m["question"],
                "link":link,
                "edge":edge
            })

    value_bets=sorted(value_bets,key=lambda x:x["edge"],reverse=True)[:10]
    watchlist=sorted(watchlist,key=lambda x:x["edge"],reverse=True)[:5]

    signals=[]
    for v in value_bets:
        signals.append(
f"- {v['question']}\n{v['link']}\nmarket={v['price']:.2f} | model={v['prob']:.2f} | edge={v['edge']:.2f}"
        )

    signals="\n\n".join(signals) if signals else "none"

    near=[]
    for w in watchlist:
        near.append(
f"- {w['question']}\n{w['link']}\nedge={w['edge']:.2f}"
        )

    near="\n\n".join(near) if near else "none"

    report=f"""Polymarket edge scan - {datetime.datetime.utcnow()}

Scanned: {len(markets)}
Accepted: {len(accepted)}

Top value bets

{signals}

Near misses

{near}

Reject reasons:
{rejects}
"""

    send_message(report)

if __name__=="__main__":
    run()
