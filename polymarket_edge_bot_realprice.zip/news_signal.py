
import random

def news_sentiment(question):
    return random.uniform(-0.1,0.3)
