
def estimated_probability(metrics):

    prob=(
        metrics["quality"]*0.35+
        metrics["momentum"]*0.15+
        metrics["anomaly"]*0.15+
        metrics["orderbook"]*0.15+
        metrics["news"]*0.20
    )

    prob=max(0.01,min(prob,0.99))

    return prob
