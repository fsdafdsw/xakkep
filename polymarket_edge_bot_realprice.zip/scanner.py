
import requests
from config import POLYMARKET_API, PAGE_SIZE

def fetch_markets(limit=5000):

    markets=[]
    offset=0

    while len(markets) < limit:

        url=f"{POLYMARKET_API}?limit={PAGE_SIZE}&offset={offset}"

        try:
            r=requests.get(url,timeout=10)
            data=r.json()

            if not data:
                break

            for m in data:

                price=None

                # Polymarket API often provides outcomePrices list
                if m.get("outcomePrices"):
                    try:
                        price=float(m["outcomePrices"][0])
                    except:
                        price=None

                markets.append({
                    "id":m.get("id"),
                    "question":m.get("question"),
                    "slug":m.get("slug"),
                    "volume":float(m.get("volume",0)),
                    "liquidity":float(m.get("liquidity",0)),
                    "price":price
                })

            offset+=PAGE_SIZE

        except Exception as e:
            print("API error",e)
            break

    return markets[:limit]
