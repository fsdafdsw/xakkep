
from features import *
from news_signal import news_sentiment

def evaluate_market(m):

    quality=compute_quality(m)
    momentum=compute_momentum(m)
    anomaly=compute_anomaly(m)
    orderbook=compute_orderbook_signal(m)
    news=news_sentiment(m["question"])

    return {
        "quality":quality,
        "momentum":momentum,
        "anomaly":anomaly,
        "orderbook":orderbook,
        "news":news
    }
