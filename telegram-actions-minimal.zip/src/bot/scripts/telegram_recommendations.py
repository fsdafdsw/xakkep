from __future__ import annotations

import json
import os
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any

import httpx


@dataclass(slots=True)
class OutcomeSignal:
    market_title: str
    outcome_label: str
    market_url: str
    market_prob: float
    model_prob: float
    edge: float
    confidence: float
    suggested_stake_usd: float
    spread: float
    depth_total: float
    score: float


def _safe_float(value: Any, fallback: float = 0.0) -> float:
    try:
        if value is None:
            return fallback
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _safe_int(value: str | None, fallback: int) -> int:
    try:
        if value is None or value == "":
            return fallback
        return int(value)
    except ValueError:
        return fallback


def _clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def _parse_list(raw: Any) -> list[Any]:
    if raw is None:
        return []
    if isinstance(raw, list):
        return raw
    if isinstance(raw, str):
        try:
            parsed = json.loads(raw)
            return parsed if isinstance(parsed, list) else []
        except json.JSONDecodeError:
            return []
    return []


def _extract_markets(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, list):
        return [item for item in payload if isinstance(item, dict)]
    if isinstance(payload, dict):
        data = payload.get("data")
        if isinstance(data, list):
            return [item for item in data if isinstance(item, dict)]
    return []


def _extract_outcomes(market: dict[str, Any]) -> list[tuple[str, str, float]]:
    token_ids = _parse_list(market.get("clobTokenIds") or market.get("tokenIds"))
    outcomes = _parse_list(market.get("outcomes"))
    outcome_prices = _parse_list(market.get("outcomePrices"))
    parsed: list[tuple[str, str, float]] = []
    for index, token_id in enumerate(token_ids):
        token = str(token_id)
        label = str(outcomes[index]) if index < len(outcomes) else f"outcome_{index + 1}"
        base_prob = _safe_float(outcome_prices[index], 0.5) if index < len(outcome_prices) else 0.5
        parsed.append((token, label, _clamp(base_prob, 0.01, 0.99)))
    return parsed


def _book_levels(book: dict[str, Any], side: str) -> list[dict[str, Any]]:
    levels = book.get(side)
    if isinstance(levels, list):
        return [entry for entry in levels if isinstance(entry, dict)]
    return []


def _book_stats(book_payload: Any) -> tuple[float, float, float, float, float, float]:
    if isinstance(book_payload, dict) and isinstance(book_payload.get("book"), dict):
        book_payload = book_payload["book"]
    if not isinstance(book_payload, dict):
        return 0.0, 1.0, 0.5, 1.0, 0.0, 0.0

    bids = _book_levels(book_payload, "bids")
    asks = _book_levels(book_payload, "asks")

    bid_prices = [_safe_float(level.get("price"), 0.0) for level in bids]
    ask_prices = [_safe_float(level.get("price"), 1.0) for level in asks]
    best_bid = max(bid_prices) if bid_prices else 0.0
    best_ask = min(ask_prices) if ask_prices else 1.0
    spread = max(best_ask - best_bid, 0.0)
    mid = (best_bid + best_ask) / 2.0 if best_ask >= best_bid else 0.5

    depth_bid = sum(_safe_float(level.get("size"), 0.0) for level in bids[:10])
    depth_ask = sum(_safe_float(level.get("size"), 0.0) for level in asks[:10])
    depth_total = max(0.0, depth_bid + depth_ask)
    imbalance = (depth_bid - depth_ask) / max(depth_total, 1e-6)
    return best_bid, best_ask, mid, spread, depth_total, imbalance


def _market_url(market: dict[str, Any]) -> str:
    slug = market.get("slug")
    if slug:
        return f"https://polymarket.com/event/{slug}"
    for key in ("url", "marketUrl", "eventUrl"):
        value = market.get(key)
        if value:
            return str(value)
    return "https://polymarket.com"


def _required_env(name: str) -> str:
    value = os.getenv(name, "").strip()
    if not value:
        raise RuntimeError(f"Environment variable {name} is required")
    return value


def _render_signal_line(index: int, signal: OutcomeSignal, bankroll_usd: float) -> str:
    edge_pct = signal.edge * 100.0
    confidence_pct = signal.confidence * 100.0
    probability_pct = signal.model_prob * 100.0
    market_pct = signal.market_prob * 100.0
    bankroll_share = 100.0 * signal.suggested_stake_usd / max(bankroll_usd, 1e-6)
    return (
        f"{index}) {signal.market_title}\n"
        f"• Исход: {signal.outcome_label}\n"
        f"• Рекомендация: BUY\n"
        f"• P(win): {probability_pct:.1f}% (рынок {market_pct:.1f}%)\n"
        f"• Edge: +{edge_pct:.2f} п.п. | Уверенность: {confidence_pct:.0f}%\n"
        f"• Ставка: ${signal.suggested_stake_usd:.2f} ({bankroll_share:.2f}% банка)\n"
        f"• Ликвидность: spread {signal.spread:.3f}, depth {signal.depth_total:.1f}\n"
        f"• Ссылка: {signal.market_url}"
    )


def _render_message(signals: list[OutcomeSignal], bankroll_usd: float) -> str:
    timestamp = datetime.now(UTC).strftime("%Y-%m-%d %H:%M UTC")
    if not signals:
        return (
            f"Polymarket сигналы ({timestamp})\n"
            "Подходящих рынков сейчас нет по заданным фильтрам.\n"
            "Это нормально: лучше пропустить вход, чем зайти в слабый edge."
        )

    lines = [f"Polymarket сигналы ({timestamp})", f"Банк для расчета: ${bankroll_usd:.2f}", ""]
    for index, signal in enumerate(signals, start=1):
        lines.append(_render_signal_line(index, signal, bankroll_usd))
        lines.append("")
    lines.append("Важно: это вероятностные рекомендации, не гарантия прибыли.")
    message = "\n".join(lines)
    return message[:3900]


def _send_telegram(token: str, chat_id: str, text: str, timeout_seconds: int) -> None:
    endpoint = f"https://api.telegram.org/bot{token}/sendMessage"
    payload = {
        "chat_id": chat_id,
        "text": text,
        "disable_web_page_preview": True,
    }
    with httpx.Client(timeout=timeout_seconds) as client:
        response = client.post(endpoint, data=payload)
        response.raise_for_status()
        result = response.json()
        if not isinstance(result, dict) or not bool(result.get("ok")):
            raise RuntimeError(f"Telegram API error: {result}")


def _build_signals() -> tuple[list[OutcomeSignal], float]:
    gamma_base = os.getenv("POLYMARKET_GAMMA_BASE_URL", "https://gamma-api.polymarket.com").rstrip("/")
    clob_base = os.getenv("POLYMARKET_CLOB_BASE_URL", "https://clob.polymarket.com").rstrip("/")
    timeout_seconds = _safe_int(os.getenv("SIGNALS_TIMEOUT_SECONDS"), 15)
    market_limit = _safe_int(os.getenv("SIGNALS_MARKET_LIMIT"), 40)
    top_n = _safe_int(os.getenv("SIGNALS_TOP_N"), 5)
    min_edge = _safe_float(os.getenv("SIGNALS_MIN_EDGE"), 0.015)
    min_quality = _safe_float(os.getenv("SIGNALS_MIN_QUALITY"), 0.50)
    depth_target = _safe_float(os.getenv("SIGNALS_DEPTH_TARGET"), 1500.0)
    bankroll_usd = max(1.0, _safe_float(os.getenv("SIGNALS_BANKROLL_USD"), 100.0))
    max_stake_fraction = _clamp(_safe_float(os.getenv("SIGNALS_MAX_STAKE_FRACTION"), 0.03), 0.002, 0.20)
    min_stake_fraction = _clamp(_safe_float(os.getenv("SIGNALS_MIN_STAKE_FRACTION"), 0.002), 0.001, max_stake_fraction)

    signals: list[OutcomeSignal] = []
    with httpx.Client(timeout=timeout_seconds, headers={"User-Agent": "polymarket-telegram-signals/0.1"}) as client:
        response = client.get(
            f"{gamma_base}/markets",
            params={"limit": market_limit, "closed": "false"},
        )
        response.raise_for_status()
        markets = _extract_markets(response.json())

        for market in markets:
            if not bool(market.get("active", True)):
                continue
            outcomes = _extract_outcomes(market)
            if not outcomes:
                continue

            market_title = str(market.get("question") or market.get("title") or "Untitled market")
            market_url = _market_url(market)

            for token_id, outcome_label, gamma_prob in outcomes:
                book_response = client.get(f"{clob_base}/book", params={"token_id": token_id})
                if book_response.status_code != 200:
                    continue
                best_bid, best_ask, mid, spread, depth_total, imbalance = _book_stats(book_response.json())
                if best_bid <= 0 or best_ask <= 0 or best_ask < best_bid:
                    continue

                spread_quality = _clamp(1.0 - spread / 0.08, 0.0, 1.0)
                depth_quality = _clamp(depth_total / max(depth_target, 1.0), 0.0, 1.0)
                quality = _clamp(0.58 * spread_quality + 0.42 * depth_quality, 0.0, 1.0)
                if quality < min_quality:
                    continue

                model_prob = _clamp(
                    mid + 0.10 * imbalance + 0.45 * (gamma_prob - mid),
                    0.01,
                    0.99,
                )
                edge = model_prob - mid
                if edge < min_edge:
                    continue

                confidence = _clamp(0.35 + 0.38 * abs(imbalance) + 0.27 * quality, 0.05, 0.97)
                score = edge * confidence * quality

                stake_fraction = _clamp(
                    score * 8.0,
                    min_stake_fraction,
                    max_stake_fraction,
                )
                suggested_stake = bankroll_usd * stake_fraction
                signals.append(
                    OutcomeSignal(
                        market_title=market_title,
                        outcome_label=outcome_label,
                        market_url=market_url,
                        market_prob=mid,
                        model_prob=model_prob,
                        edge=edge,
                        confidence=confidence,
                        suggested_stake_usd=suggested_stake,
                        spread=spread,
                        depth_total=depth_total,
                        score=score,
                    )
                )

    signals.sort(key=lambda item: item.score, reverse=True)
    return signals[: max(1, top_n)], bankroll_usd


def main() -> None:
    telegram_token = _required_env("TELEGRAM_BOT_TOKEN")
    telegram_chat_id = _required_env("TELEGRAM_CHAT_ID")
    timeout_seconds = _safe_int(os.getenv("SIGNALS_TIMEOUT_SECONDS"), 15)

    try:
        signals, bankroll_usd = _build_signals()
        message = _render_message(signals, bankroll_usd=bankroll_usd)
        _send_telegram(
            token=telegram_token,
            chat_id=telegram_chat_id,
            text=message,
            timeout_seconds=timeout_seconds,
        )
    except Exception as exc:
        error_text = f"Polymarket сигналы: ошибка запуска\n{type(exc).__name__}: {exc}"
        _send_telegram(
            token=telegram_token,
            chat_id=telegram_chat_id,
            text=error_text[:3900],
            timeout_seconds=timeout_seconds,
        )
        raise


if __name__ == "__main__":
    main()
